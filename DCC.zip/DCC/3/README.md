# Mission 3 — 119 신고 통화 증상 분류 (NLI 기반 다중 라벨)

# 디렉터리 구조
    Mission3/
    ├─ inference.py        # 추론 실행 스크립트
    ├─ model.py            # 전처리·모델 로드·추론 함수 정의
    ├─ requirements.txt
    ├─ README.md
    ├─ ckpt/               # 학습 완료 모델 (아래 파일 모두 필요)
    │   ├─ config.json
    │   ├─ model.safetensors
    │   ├─ tokenizer.json
    │   ├─ tokenizer_config.json
    └─ outputs/            # 결과 csv 생성 위치

# 실행 환경
- Window 11, Colab 둘 다 가능
- Python 3.13
- torch 2.11.0 (CUDA 13.0 빌드, GPU 없으면 CPU로 자동 동작)
- transformers 5.16.1

> GPU 드라이버 CUDA 버전이 13.0 미만이면 `requirements.txt` 상단 주석을 참고해 torch 빌드를 변경하세요.

# 실행 {}에 실제 경로 입력
!python inference.py --audio_dir {wav folder} --label_dir {json folder} --ckpt_path ./ckpt --output ./outputs/mission3.csv

# 출력 형식
`outputs/mission3.csv` (UTF-8 with BOM)

```
label file name,symptom
call_0001.json,"어지러움, 구토"
call_0002.json,호흡곤란
```

# 학습 재현
`M3_Training_log.ipynb` 참고 
