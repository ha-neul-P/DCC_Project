# inference.py
import argparse, glob, json, os, sys
import numpy as np, pandas as pd, torch
from model import LABELS, build_text, load_trained, predict_probs, to_pred, vec_to_symptoms

def load_label_dir(label_dir):
    paths = sorted(p for p in glob.glob(os.path.join(label_dir, "**", "*.json"), recursive=True)
                   if not os.path.basename(p).startswith("._"))
    if not paths: sys.exit(f"[오류] {label_dir} 아래에 .json 없음")
    rows = []
    for p in paths:
        with open(p, encoding="utf-8") as f: data = json.load(f)
        for obj in (data if isinstance(data, list) else [data]):
            if isinstance(obj, dict):
                rows.append({"file": os.path.basename(p), "text": build_text(obj)})
    return rows

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--audio_dir", required=True)
    ap.add_argument("--label_dir", required=True)
    ap.add_argument("--ckpt_path", required=True)
    ap.add_argument("--output",    required=True)
    ap.add_argument("--batch_size", type=int, default=32)
    ap.add_argument("--sep", default=", ")
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    rows = load_label_dir(args.label_dir)
    model, tok = load_trained(args.ckpt_path, device)
    probs = predict_probs(model, tok, [r["text"] for r in rows], device, args.batch_size)
    pred  = to_pred(probs)

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    pd.DataFrame({
        "label file name": [r["file"] for r in rows],
        "symptom": [args.sep.join(vec_to_symptoms(v)) for v in pred],
    }).to_csv(args.output, index=False, encoding="utf-8-sig")
    print(f"저장 위치:  {args.output} ({len(rows)}행)")

if __name__ == "__main__":
    main()

# python inference.py --audio_dir ./data/Validation/VL_서울_구급 --label_dir ./data/Validation/VL_서울_구급 --ckpt_path ./ckpt --output ./outputs/mission3.csv