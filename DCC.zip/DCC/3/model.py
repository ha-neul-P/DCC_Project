"""
사용 예시
  from model import load_tokenizer, build_model, load_trained, predict_probs, to_pred
"""
import os, re
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import (AutoTokenizer, AutoModelForSequenceClassification,
                          AutoConfig, Trainer, DataCollatorWithPadding)
from sklearn.metrics import f1_score


# 상수
MODEL_NAME = "klue/roberta-base"
MAX_LEN    = 512
SEED       = 42
LABELS = ["고열", "구토", "두통", "복통", "어지러움", "열상", "오심", "전신쇠약", "호흡곤란"]
L2I = {l: i for i, l in enumerate(LABELS)}
N_LABELS = len(LABELS)
THRESHOLD = 0.5

HYPOTHESES = {
    "고열":     "환자에게 고열이 있거나 열이 높다",
    "구토":     "환자가 구토를 했거나 토했다",
    "두통":     "환자가 두통이 있거나 머리가 아프다",
    "복통":     "환자가 복통이 있거나 배가 아프다",
    "어지러움": "환자가 어지럽거나 현기증이 있다",
    "열상":     "환자에게 열상이 있거나 베이고 찢어져 피가 난다",
    "오심":     "환자가 메스껍거나 속이 울렁거리거나 구역질이 난다",
    "전신쇠약": "환자가 기운이 없고 힘이 없거나 축 늘어져 있다",
    "호흡곤란": "환자가 숨쉬기 힘들거나 호흡이 곤란하다",
}
HYP_LIST = [HYPOTHESES[l] for l in LABELS]

# 전처리 플래그 (학습 때 값과 동일함)
USE_SPEAKER = True
MASK_TITLE  = True
MASK_AGE    = True
MASK_MODE   = "token"

SPK_TOKEN  = {0: "[대원]", 1: "[신고자]", "0": "[대원]", "1": "[신고자]"}
NEW_TOKENS = ["[대원]", "[신고자]", "[호칭]", "[나이]"]
EXPECTED_VOCAB = 32004

# Focal Loss 하이퍼파라미터
FOCAL_ALPHA = [0.5, 1.5]
FOCAL_GAMMA = 2.0


# 전처리
TITLES = sorted([
    "외할아버지","외할머니","할아버지","할머니","할아버님","할머님","할배","할매",
    "친정어머니","시어머니","시아버지","장인어른","장모님","장모","장인",
    "아버지","어머니","아버님","어머님","아빠","엄마","부모님",
    "남편","아내","와이프","신랑","집사람","안식구","바깥양반",
    "딸내미","아들내미","아들","딸","막내","큰애","작은애","첫째","둘째",
    "아기","애기","아가","어린애","아이","애가","애를","애도","애는",
    "손자","손녀","며느리","사위","조카","형님","누나","오빠","언니","동생","형제","형",
    "어르신","노인","학생","아저씨","아줌마","아가씨","총각","청년",
    "환자분","남자분","여자분","남성","여성","남자","여자",
], key=len, reverse=True)
TITLE_RE = re.compile(r"(" + "|".join(map(re.escape, TITLES)) +
                      r")(?=[가이는은을를도의만께랑과와한테에서분님씨]|\s|[,.?!]|$)")
AGE_RE = re.compile(r"(\d{1,3}\s*(살|세|개월|대)|[가-힣]{1,4}\s?(살|세)(?=\s|[,.?!이에요요]|$))")


def mask_text(t: str) -> str:
    rep_t = "[호칭]" if MASK_MODE == "token" else ""
    rep_a = "[나이]" if MASK_MODE == "token" else ""
    if MASK_TITLE: t = TITLE_RE.sub(rep_t, t)
    if MASK_AGE:   t = AGE_RE.sub(rep_a, t)
    return re.sub(r"\s{2,}", " ", t).strip()


def build_text(obj: dict) -> str:
    # 라벨 json 1건(dict) → 전처리된 통화 텍스트 1줄
    parts = []
    for u in obj.get("utterances", []) or []:
        t = (u.get("text") or "").strip()
        if not t:
            continue
        t = mask_text(t)
        if USE_SPEAKER:
            t = f"{SPK_TOKEN.get(u.get('speaker'), '')} {t}".strip()
        parts.append(t)
    return " ".join(parts)


def rows_to_nli(rows):
    out = []
    for r in rows:
        y = r.get("y")
        for j, l in enumerate(LABELS):
            out.append({
                "text": r["text"],
                "hypothesis": HYPOTHESES[l],
                "label": int(y[j]) if y is not None else -1,
            })
    return out


def encode_nli(tok, texts, hyps, padding=False, return_tensors=None):
    enc = tok(texts, hyps, truncation="only_first", max_length=MAX_LEN,
              padding=padding, return_tensors=return_tensors)
    enc.pop("token_type_ids", None)
    return enc

# ═══════════════════════════════════════════════
# 3) 토크나이저 / 모델
# ═══════════════════════════════════════════════
def load_tokenizer(src: str = MODEL_NAME):
    tok = AutoTokenizer.from_pretrained(src)
    if len(tok) < EXPECTED_VOCAB:
        tok.add_special_tokens({"additional_special_tokens": NEW_TOKENS})
    assert len(tok) == EXPECTED_VOCAB, f"vocab {len(tok)} ≠ {EXPECTED_VOCAB}"
    return tok


def build_model(tok, base: str = MODEL_NAME):
    model = AutoModelForSequenceClassification.from_pretrained(base, num_labels=2)
    model.resize_token_embeddings(len(tok))
    return model


def _strip_prefix(sd: dict) -> dict:
    for pre in ("model.", "module."):
        if sd and all(k.startswith(pre) for k in sd):
            sd = {k[len(pre):]: v for k, v in sd.items()}
    return sd


def load_trained(ckpt_path: str, device: str = "cpu"):
    ckpt_path = os.path.abspath(ckpt_path)
    model_dir = ckpt_path if os.path.isdir(ckpt_path) else os.path.dirname(ckpt_path)
    has_cfg = os.path.exists(os.path.join(model_dir, "config.json"))
    has_tok = os.path.exists(os.path.join(model_dir, "tokenizer_config.json"))
    is_hf   = os.path.isdir(ckpt_path) or ckpt_path.endswith((".safetensors", "pytorch_model.bin"))

    tok = load_tokenizer(model_dir if has_tok else MODEL_NAME)

    if has_cfg and is_hf:
        model = AutoModelForSequenceClassification.from_pretrained(model_dir)
    else:
        if ckpt_path.endswith(".safetensors"):
            from safetensors.torch import load_file
            sd = load_file(ckpt_path)
        else:
            sd = torch.load(ckpt_path, map_location="cpu", weights_only=False)
        for key in ("state_dict", "model_state_dict"):
            if isinstance(sd, dict) and key in sd:
                sd = sd[key]
        if not isinstance(sd, dict):              # 모델 객체 통째로 저장된 경우
            model = sd
        else:
            sd = _strip_prefix(sd)
            if has_cfg:
                model = AutoModelForSequenceClassification.from_config(
                    AutoConfig.from_pretrained(model_dir))
            else:
                model = build_model(tok)
            missing, unexpected = model.load_state_dict(sd, strict=False)
            if missing or unexpected:
                print(f"[경고] missing={len(missing)} unexpected={len(unexpected)}")

    emb = model.get_input_embeddings().weight.shape[0]
    assert emb == len(tok), f"임베딩 {emb} ≠ vocab {len(tok)}"
    assert model.config.num_labels == 2, f"num_labels={model.config.num_labels} (NLI 는 2)"
    return model.to(device).eval(), tok

# 학습용: Focal Loss / Trainer / metrics
class FocalLoss(nn.Module):
    def __init__(self, alpha=None, gamma=2.0):
        super().__init__()
        self.gamma = gamma
        self.alpha = torch.tensor(alpha, dtype=torch.float32) if alpha is not None else None

    def forward(self, logits, labels):
        labels = labels.view(-1).long()
        ce = F.cross_entropy(logits, labels, reduction="none")
        pt = torch.exp(-ce)
        focal = ((1 - pt) ** self.gamma) * ce
        if self.alpha is not None:
            at = self.alpha.to(logits.device)[labels]
            focal = at * focal
        return focal.mean()


class NLITrainer(Trainer):
    def __init__(self, *args, focal_alpha=FOCAL_ALPHA, focal_gamma=FOCAL_GAMMA, **kwargs):
        super().__init__(*args, **kwargs)
        self.loss_fn = FocalLoss(alpha=focal_alpha, gamma=focal_gamma)

    def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
        labels = inputs.pop("labels").long()
        outputs = model(**inputs)
        loss = self.loss_fn(outputs.logits, labels)
        return (loss, outputs) if return_outputs else loss


def compute_metrics(eval_pred):
    # NLI 쌍 예측(N*9) → (N, 9) 복원 → threshold 0.5 macro F1
    logits, labels = eval_pred
    probs = torch.softmax(torch.tensor(logits, dtype=torch.float32), dim=-1)[:, 1].numpy()
    labels = np.array(labels, dtype=int).ravel()
    n = len(probs) // N_LABELS
    probs  = probs[: n * N_LABELS].reshape(n, N_LABELS)
    labels = labels[: n * N_LABELS].reshape(n, N_LABELS)
    preds  = (probs >= THRESHOLD).astype(int)
    f1_per = [f1_score(labels[:, i], preds[:, i], zero_division=0) for i in range(N_LABELS)]
    result = {"macro_f1_05": round(float(np.mean(f1_per)), 4)}
    for i, name in enumerate(LABELS):
        result[f"f1_{name}"] = round(f1_per[i], 4)
    return result


def get_collator(tok):
    return DataCollatorWithPadding(tok)


# 추론 유틸
@torch.no_grad()
def predict_probs(model, tok, texts, device="cpu", batch_size=32, fp16=True, verbose=True):
    """통화 텍스트 N개 → (N, 9) entailment 확률"""
    premises, hyps = [], []
    for t in texts:
        for h in HYP_LIST:
            premises.append(t); hyps.append(h)
    probs = np.zeros(len(premises), dtype=np.float32)
    use_amp = fp16 and str(device).startswith("cuda")
    for s in range(0, len(premises), batch_size):
        enc = encode_nli(tok, premises[s:s+batch_size], hyps[s:s+batch_size],
                         padding=True, return_tensors="pt")
        enc = {k: v.to(device) for k, v in enc.items()}
        with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=use_amp):
            logits = model(**enc).logits
        probs[s:s+batch_size] = torch.softmax(logits.float(), dim=-1)[:, 1].cpu().numpy()
        if verbose:
            done = min(s + batch_size, len(premises))
            print(f"\r  추론 {done}/{len(premises)} 쌍 ({done // N_LABELS}/{len(texts)} 통화)",
                  end="", flush=True)
    if verbose: print()
    return probs.reshape(len(texts), N_LABELS)


def to_pred(probs: np.ndarray, thr: float = THRESHOLD) -> np.ndarray:
    # thr 이상 → 1, 전부 미만이면 최댓값 1개 강제
    pred = (probs >= thr).astype(int)
    empty = pred.sum(1) == 0
    if empty.any():
        pred[empty, probs[empty].argmax(1)] = 1
    return pred


def vec_to_symptoms(vec) -> list:
    return [LABELS[i] for i in np.where(vec)[0]]


__all__ = [
    "MODEL_NAME", "MAX_LEN", "LABELS", "N_LABELS", "HYPOTHESES", "HYP_LIST", "THRESHOLD",
    "mask_text", "build_text", "rows_to_nli", "encode_nli",
    "load_tokenizer", "build_model", "load_trained",
    "FocalLoss", "NLITrainer", "compute_metrics", "get_collator",
    "predict_probs", "to_pred", "vec_to_symptoms",
]
