import os
import json
import shutil
import numpy as np
import pandas as pd
import soundfile as sf
import librosa
from sklearn.metrics import roc_auc_score, accuracy_score
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import WavLMModel
from tqdm import tqdm

import gc
import time

class AudioDataset(Dataset):
    def __init__(self, meta_df, data_dir):
        self.meta = meta_df
        self.shards = {}
        for s in self.meta['shard'].unique():
            self.shards[s] = np.load(f"{data_dir}/shard_{s:03d}.npy", mmap_mode='r')

    def __len__(self):
        return len(self.meta)

    def __getitem__(self, idx):
        row = self.meta.iloc[idx]
        shard_idx = row['shard']
        offset = int(row['offset'])
        length = int(row['length'])

        segment = np.array(self.shards[shard_idx][offset:offset + length])
        waveform = torch.tensor(segment, dtype=torch.float32) / 32768.0
        label = torch.tensor(row['speaker_true'], dtype=torch.float32)

        return waveform, label

def collate_fn(batch):
    waveforms, labels = zip(*batch)
    lengths = [w.size(0) for w in waveforms]
    max_len = max(lengths)

    padded_waveforms = torch.zeros(len(waveforms), max_len)
    attention_mask = torch.zeros(len(waveforms), max_len, dtype=torch.long)

    for i, (w, l) in enumerate(zip(waveforms, lengths)):
        padded_waveforms[i, :l] = w
        attention_mask[i, :l] = 1

    labels = torch.stack(labels)
    return padded_waveforms, attention_mask, labels

class WavLMClassifier(nn.Module):
    def __init__(self, model_name='./wavlm_base_plus'):
        super().__init__()
        self.wavlm = WavLMModel.from_pretrained(model_name)
        self.classifier = nn.Sequential(
            nn.Linear(self.wavlm.config.hidden_size, 128),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(128, 1),
            nn.Sigmoid()
        )

    def forward(self, x, attention_mask=None):
        outputs = self.wavlm(x, attention_mask=attention_mask)
        hidden_states = outputs.last_hidden_state.mean(dim=1)
        return self.classifier(hidden_states).squeeze(-1)

def run_inference_pipeline(audio_dir, label_dir, ckpt_path, model_path='./wavlm_base_plus', cache_dir='./temp_cache'):
    os.makedirs(cache_dir, exist_ok=True)

    FILES_PER_SHARD, TARGET_SR = 1000, 8000
    wav_names = sorted(f for f in os.listdir(audio_dir) if f.endswith('.wav'))
    meta_rows = []

    print("데이터 전처리 및 조각 분리 시작...")
    for s_idx, start in enumerate(range(0, len(wav_names), FILES_PER_SHARD)):
        chunks, offset = [], 0
        for name in wav_names[start:start + FILES_PER_SHARD]:
            base = os.path.splitext(name)[0]
            jpath = os.path.join(label_dir, base + '.json')

            if not os.path.exists(jpath):
                continue

            wav, sr = sf.read(os.path.join(audio_dir, name), dtype='int16')
            if wav.ndim == 2:
                wav = wav.mean(axis=1).astype(np.int16)
            if sr != TARGET_SR:
                wav = (librosa.resample(wav.astype(np.float32) / 32768, orig_sr=sr, target_sr=TARGET_SR) * 32768).clip(-32768, 32767).astype(np.int16)

            with open(jpath, encoding='utf-8') as f:
                utts = json.load(f).get('utterances', [])

            for u in utts:
                s = int(u['startAt'] * TARGET_SR / 1000)
                e = min(int(u['endAt'] * TARGET_SR / 1000), len(wav))
                seg = wav[s:e]
                if len(seg) == 0:
                    continue
                chunks.append(seg)

                meta_rows.append({
                    'audio file name': name,
                    'startAt': u['startAt'],
                    'endAt': u['endAt'],
                    'shard': s_idx,
                    'offset': offset,
                    'length': len(seg),
                    'speaker_true': u.get('speaker', 0)
                })
                offset += len(seg)

        if chunks:
            np.save(f'{cache_dir}/shard_{s_idx:03d}.npy', np.concatenate(chunks))

    meta_df = pd.DataFrame(meta_rows)
    meta_df.to_csv(f'{cache_dir}/meta.csv', index=False)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = WavLMClassifier(model_name=model_path).to(device)
    model.load_state_dict(torch.load(ckpt_path, map_location=device, weights_only=True))
    model.eval()

    dataset = AudioDataset(meta_df, cache_dir)
    loader = DataLoader(dataset, batch_size=16, shuffle=False, collate_fn=collate_fn)
    criterion = nn.BCELoss()

    all_preds, all_probs, all_labels, all_losses = [], [], [], []

    with torch.no_grad():
        for waveforms, masks, labels in tqdm(loader, desc="추론 진행 중"):
            waveforms = waveforms.to(device)
            masks = masks.to(device)
            labels = labels.to(device)

            outputs = model(waveforms, attention_mask=masks)
            loss = criterion(outputs, labels)

            all_losses.append(loss.item())

            probs = outputs.cpu().numpy()
            preds = (probs >= 0.5).astype(int)

            all_probs.extend(probs)
            all_preds.extend(preds)
            all_labels.extend(labels.cpu().numpy())

    meta_df['speaker'] = all_preds
    result_df = meta_df[['audio file name', 'startAt', 'endAt', 'speaker']]

    final_loss = np.mean(all_losses)
    final_acc = accuracy_score(all_labels, all_preds)
    final_auc = roc_auc_score(all_labels, all_probs)

    print(f"Loss: {final_loss:.4f}")
    print(f"ACC:  {final_acc:.4f}")
    print(f"AUC:  {final_auc:.4f}")

    dataset.shards.clear()
    del dataset
    del loader
    gc.collect()
    time.sleep(1)

    try:
        shutil.rmtree(cache_dir)
        print("임시 데이터 정리 완료.")
    except Exception as e:
        print(f"임시 파일 삭제 중 오류가 발생: {e}")

    return result_df