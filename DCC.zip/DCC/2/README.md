# inference.py
본 코드가 위치하는 폴더(이하 root)에 다음 파일들(폴더)이 있는 것을 권장
    * root에 없는 경우 실행방법에서 경로 입력시 상대경로(./ 등) 대신 절대 경로 입력 
    wavlm_base_plus 폴더 : model의 config, model.safetensors 가 있어서 inference.py에서 모델 로드 시 사용
    weights.pt : 학습된 가중치 파일
    requirements.txt : python 라이브러리 구현 시 사용 
    requirements1.txt : colab 실행 시 라이브러리 구현에 사용 
    추론할 data set 경로 (wav, json이 있는 폴더)
    model.py : inference.py에서 import 
    
실행방법 (윈도우)
    1. root에서 cmd 실행 (또는 코드 실행환경에서 root로 이동)
    2. pip install -r requirements.txt 실행 : 라이브러리 설치 
    3. python inference.py --audio_dir {wav folder} --label_dir {json folder} --ckpt_path {checkpoint file} 
       --output ./outputs/ mission{미션번호}.csv 실행 * {}에 실제 경로 입력 
    
    inference.py 실행 test 환경 : 
        제품명 : 삼성 갤럭시 북 4 pro
        프로세서(CPU) : Intel(R) Core(TM) Ultra 5 125H(3.60 GHz)
        RAM : 16.0GB
        그래픽 카드 : Intel(R) Arc(TM) Graphics (128 MB)
        OS : Windows 11 Home
        python : 3.11.9 (64-bit)
        제공받은 Validation set으로 test 해 본 결과 정상 실행 확인 
        * 노트북에서 실행 당시 그래픽 카드가 내장 그래픽이랑 실행시간이 매우 길었음, 그래픽 카드 있는 환경에서 실행 권장

실행방법 (colab) : 윈도우 보안 정책이나 파이썬 버전으로 인해 라이브러리 호환이 안 될 경우 코랩 실행 권장

코랩 작업 환경에 위의 폴더 파일들 옮긴 후 다음 명령어들 차례로 실행

!pip install -r requirements1.txt

!python inference.py --audio_dir {wav folder} --label_dir {json folder} --ckpt_path {checkpoint file} --output ./outputs/ mission{미션번호}.csv 실행 
* {}에 실제 경로 입력 



# 학습 코드 파일 : 자세한 설명은 코드 주석 및 실행 결과 확인
M2_sample.ipynb : 전처리 유무의 성능 비교를 위해 Train set 중 일부만 사용한 학습 코드
M2_full.ipynb : Train set 전체 학습 및 Validation set 이용해 검증 (검증 단계에서는 파인튜닝 진행되지 않음)

