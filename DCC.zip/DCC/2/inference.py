import os
import argparse
from model import run_inference_pipeline

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--audio_dir', type=str, required=True)
    parser.add_argument('--label_dir', type=str, required=True)
    parser.add_argument('--ckpt_path', type=str, required=True)
    parser.add_argument('--output', type=str, required=True)
    args = parser.parse_args()

    out_dir = os.path.dirname(args.output)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    # model.py의 파이프라인 실행 후 결과 DataFrame 반환
    result_df = run_inference_pipeline(
        audio_dir=args.audio_dir,
        label_dir=args.label_dir,
        ckpt_path=args.ckpt_path
    )

    # 반환된 결과를 csv로 저장
    result_df.to_csv(args.output, index=False, encoding='utf-8-sig')
    print(f"결과물 저장 완료: {args.output}")

if __name__ == "__main__":
    main()