# ==============================================================================
# [Mission 1] 119 신고 전화 음성 기반 신고자 성별 분류 추론 (Inference) 엔진
# - 실행 규격:
#     python inference.py --audio_dir {wav folder} --label_dir {json folder} \
#                         --ckpt_path {checkpoint file} --output ./outputs/mission1.csv
# - 결과 포맷:
#     audio file name,gender
#     651e464d69a4f266f06268a0_20220101.wav,M
#     651e464d69a4f266f06268a1_20220101.wav,F
# - 규정 준수:
#     라벨링 데이터(.json)에서 오직 'startAt', 'endAt', 'speaker' 정보만 활용
# ==============================================================================

import os
import sys
import time
import json
import argparse
import warnings
import wave
import platform

# 모델코드를 외부에서 불러올 경우
# from models import InferenceConfig, GPUMelFrontEnd, AudioClassifierCNN

# Windows 콘솔 등 인코딩 이슈 방지
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd

# 오디오 I/O 라이브러리 (Colab 기본 탑재, 로컬 환경 내장 wave 폴백)
try:
    import soundfile as sf
except ImportError:
    sf = None

try:
    import librosa
except ImportError:
    librosa = None

try:
    import torch
    import torch.nn as nn
    import torchaudio.transforms as T
except ImportError:
    torch = None
    nn = None
    T = None

warnings.filterwarnings("ignore")


# ------------------------------------------------------------------------------
# 0. 추론 파이프라인 기본 설정 (SSOT)
# ------------------------------------------------------------------------------
class InferenceConfig:
    TARGET_SR: int = 8000               # 8,000Hz (전화 대역 최적화)
    TARGET_DURATION: float = 3.0        # 3초 고정 윈도우
    TARGET_SAMPLES: int = int(TARGET_SR * TARGET_DURATION)  # 24,000 samples
    STRIDE_SEC: float = 1.5             # 1.5초 스트라이드 (50% 중첩 슬라이싱)
    STRIDE_SAMPLES: int = int(TARGET_SR * STRIDE_SEC)       # 12,000 samples
    MIN_SEG_DURATION: float = 0.3       # 0.3초 미만 발화 노이즈 제외
    SILENCE_GAP_SEC: float = 0.1        # 발화 연결 시 삽입할 무음 버퍼

    # Mel-Spectrogram 파라미터
    N_FFT: int = 512
    WIN_LENGTH: int = 400
    HOP_LENGTH: int = 160
    N_MELS: int = 80
    F_MIN: float = 50.0
    F_MAX: float = 3800.0


# ------------------------------------------------------------------------------
# 1. 오디오 로드 및 전처리 유틸리티
# ------------------------------------------------------------------------------
def load_audio_file(wav_path: Union[str, Path], target_sr: int = 8000) -> np.ndarray:
    """WAV 파일을 모노 float32 (-1.0 ~ 1.0) 형태로 로드하고 8kHz로 정규화합니다."""
    wav_path = str(wav_path)

    if sf is not None:
        y, orig_sr = sf.read(wav_path, dtype="float32")
        if y.ndim > 1:
            y = np.mean(y, axis=1)
    else:
        with wave.open(wav_path, "rb") as wf:
            orig_sr = wf.getframerate()
            n_channels = wf.getnchannels()
            sampwidth = wf.getsampwidth()
            n_frames = wf.getnframes()
            audio_bytes = wf.readframes(n_frames)

            if sampwidth == 2:
                raw_data = np.frombuffer(audio_bytes, dtype=np.int16)
                y = raw_data.astype(np.float32) / 32768.0
            elif sampwidth == 4:
                raw_data = np.frombuffer(audio_bytes, dtype=np.int32)
                y = raw_data.astype(np.float32) / 2147483648.0
            else:
                raw_data = np.frombuffer(audio_bytes, dtype=np.int16)
                y = raw_data.astype(np.float32) / 32768.0

            if n_channels > 1:
                y = y.reshape(-1, n_channels).mean(axis=1)

    if orig_sr != target_sr:
        if librosa is not None:
            y = librosa.resample(y, orig_sr=orig_sr, target_sr=target_sr)
        else:
            old_indices = np.linspace(0, len(y) - 1, len(y))
            new_len = int(len(y) * target_sr / orig_sr)
            new_indices = np.linspace(0, len(y) - 1, new_len)
            y = np.interp(new_indices, old_indices, y).astype(np.float32)

    return y.astype(np.float32)


def preprocess_single_call(
    wav_path: Union[str, Path],
    json_path: Optional[Union[str, Path]] = None
) -> List[np.ndarray]:
    """
    폴더 내 개별 음성 파일과 매칭되는 JSON 라벨을 기반으로 전처리를 수행합니다.
    - JSON 제공 시: 대회 규정에 따라 'startAt', 'endAt', 'speaker==1' 정보만 추출
    - JSON 미제공/오류 시: 전체 음원 기반 슬라이싱 폴백
    """
    wav_path = Path(wav_path)
    if not wav_path.is_file():
        raise FileNotFoundError(f"❌ 음성 파일을 찾을 수 없습니다: {wav_path}")

    caller_intervals = []
    if json_path is not None:
        json_path = Path(json_path)
        if json_path.is_file():
            try:
                with open(json_path, "r", encoding="utf-8") as f:
                    meta = json.load(f)
                utterances = meta.get("utterances", [])
                for utt in utterances:
                    speaker_id = str(utt.get("speaker", "")).strip()
                    if speaker_id in ["1", "1.0"]:
                        start_sec = float(utt.get("startAt", 0)) / 1000.0
                        end_sec = float(utt.get("endAt", 0)) / 1000.0
                        if (end_sec - start_sec) >= InferenceConfig.MIN_SEG_DURATION:
                            caller_intervals.append((start_sec, end_sec))
            except Exception:
                caller_intervals = []

    # 2. 음원 로드
    y = load_audio_file(wav_path, target_sr=InferenceConfig.TARGET_SR)
    target_sr = InferenceConfig.TARGET_SR
    target_samples = InferenceConfig.TARGET_SAMPLES
    stride_samples = InferenceConfig.STRIDE_SAMPLES

    # 신고자 발화가 없을 때 폴백
    if not caller_intervals:
        total_len = len(y)
        if total_len == 0:
            return [np.zeros(target_samples, dtype=np.float32)]
        if total_len < target_samples:
            return [np.pad(y, (0, target_samples - total_len), mode="constant")]
        return [y[s:s + target_samples] for s in range(0, total_len - target_samples + 1, stride_samples)]

    # 3. 발화 세그먼트 연결 (0.1초 무음 버퍼링)
    silence_gap = np.zeros(int(InferenceConfig.SILENCE_GAP_SEC * target_sr), dtype=np.float32)
    segments = []
    for s_sec, e_sec in caller_intervals:
        s_idx = max(0, int(s_sec * target_sr))
        e_idx = min(len(y), int(e_sec * target_sr))
        if e_idx > s_idx:
            segments.append(y[s_idx:e_idx])
            segments.append(silence_gap)

    if not segments:
        return [np.zeros(target_samples, dtype=np.float32)]

    caller_y = np.concatenate(segments)

    # 5. 3초 윈도우 / 1.5초 스트라이드 슬라이싱
    total_len = len(caller_y)
    chunks = []
    if total_len < target_samples:
        chunks.append(np.pad(caller_y, (0, target_samples - total_len), mode="constant"))
    else:
        for start in range(0, total_len - target_samples + 1, stride_samples):
            chunks.append(caller_y[start:start + target_samples])

        last_end = (len(chunks) - 1) * stride_samples + target_samples if chunks else 0
        tail_start = len(chunks) * stride_samples
        if last_end < total_len and (total_len - tail_start) >= int(0.5 * target_sr):
            tail = caller_y[tail_start:]
            chunks.append(np.pad(tail, (0, target_samples - len(tail)), mode="constant"))

    return chunks


# ------------------------------------------------------------------------------
# 2. 딥러닝 모델 아키텍처 (GPUMelFrontEnd + 4-Block Residual CNN)
# ------------------------------------------------------------------------------
# 외부에서 모델 코드를 불러올 경우 해당 블럭 전체를 주석 처리

if torch is not None:
    class GPUMelFrontEnd(nn.Module):
        def __init__(self, sample_rate: int = 8000):
            super().__init__()
            self.mel_transform = T.MelSpectrogram(
                sample_rate=sample_rate,
                n_fft=InferenceConfig.N_FFT,
                win_length=InferenceConfig.WIN_LENGTH,
                hop_length=InferenceConfig.HOP_LENGTH,
                n_mels=InferenceConfig.N_MELS,
                f_min=InferenceConfig.F_MIN,
                f_max=InferenceConfig.F_MAX
            )
            self.amp_to_db = T.AmplitudeToDB()

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            mel = self.amp_to_db(self.mel_transform(x)).unsqueeze(1)
            mean = mel.mean(dim=[-2, -1], keepdim=True)
            std = mel.std(dim=[-2, -1], keepdim=True) + 1e-6
            return (mel - mean) / std

    class ConvBlock(nn.Module):
        def __init__(self, in_c: int, out_c: int):
            super().__init__()
            self.conv = nn.Sequential(
                nn.Conv2d(in_c, out_c, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(out_c),
                nn.SiLU(),
                nn.Conv2d(out_c, out_c, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(out_c),
                nn.SiLU(),
                nn.MaxPool2d(2, 2)
            )
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_c, out_c, kernel_size=1, bias=False),
                nn.BatchNorm2d(out_c),
                nn.MaxPool2d(2, 2)
            )

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            return self.conv(x) + self.shortcut(x)

    class AudioClassifierCNN(nn.Module):
        def __init__(self, num_classes: int = 2):
            super().__init__()
            self.layer1 = ConvBlock(1, 32)
            self.layer2 = ConvBlock(32, 64)
            self.layer3 = ConvBlock(64, 128)
            self.layer4 = ConvBlock(128, 256)
            self.gap = nn.AdaptiveAvgPool2d((1, 1))
            self.fc = nn.Sequential(
                nn.Dropout(0.4),
                nn.Linear(256, 128),
                nn.SiLU(),
                nn.Dropout(0.2),
                nn.Linear(128, num_classes)
            )

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            x = self.layer1(x)
            x = self.layer2(x)
            x = self.layer3(x)
            x = self.layer4(x)
            x = self.gap(x).flatten(1)
            return self.fc(x)
else:
    GPUMelFrontEnd = None
    ConvBlock = None
    AudioClassifierCNN = None


# ------------------------------------------------------------------------------
# 3. 모델 로더 및 추론 파이프라인 엔진
# ------------------------------------------------------------------------------
class GenderInferenceEngine:
    def __init__(self, ckpt_path: Union[str, Path], device: Optional[str] = None):
        if torch is None:
            raise ImportError("❌ PyTorch가 설치되어 있지 않습니다. 'pip install torch torchaudio'를 실행해주세요.")

        self.ckpt_path = Path(ckpt_path)
        if not self.ckpt_path.is_file():
            raise FileNotFoundError(f"❌ 체크포인트 파일을 찾을 수 없습니다: {self.ckpt_path}")

        # 연산 디바이스
        self.device = torch.device(device if device else ("cuda" if torch.cuda.is_available() else "cpu"))

        # 모델 및 프론트엔드 초기화
        self.frontend = GPUMelFrontEnd(sample_rate=InferenceConfig.TARGET_SR).to(self.device)
        self.model = AudioClassifierCNN(num_classes=2).to(self.device)

        # 가중치 로드
        state_dict = torch.load(self.ckpt_path, map_location=self.device)
        self.train_env_info = "미기록 (가중치 파일에 미포함)"
        if isinstance(state_dict, dict):
            if "env" in state_dict:
                self.train_env_info = str(state_dict["env"])
            elif "device" in state_dict:
                self.train_env_info = str(state_dict["device"])
            elif "epoch" in state_dict or "loss" in state_dict:
                self.train_env_info = f"Epoch: {state_dict.get('epoch', 'N/A')}, Val Loss: {state_dict.get('loss', 'N/A')}"
            if "model" in state_dict:
                state_dict = state_dict["model"]

        self.model.load_state_dict(state_dict)

        self.frontend.eval()
        self.model.eval()

    def get_model_specs(self) -> Dict[str, Union[int, float]]:
        """(1) 모델의 Total 파라미터 수 및 Active(Trainable) 파라미터 수 계산"""
        total_params = sum(p.numel() for p in self.model.parameters())
        active_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        model_size_mb = sum(p.numel() * p.element_size() for p in self.model.parameters()) / (1024 * 1024)
        return {
            "total_params": total_params,
            "active_params": active_params,
            "model_size_mb": model_size_mb,
        }

    def infer_call(self, wav_path: Path, json_path: Optional[Path] = None) -> Tuple[int, float, int]:
        """
        단일 통화에 대한 전처리 및 모델 추론을 수행하고 (예측 라벨 0 or 1, 여성 확률, 청크 개수)을 반환합니다.
        """
        chunks = preprocess_single_call(wav_path, json_path)
        batch_np = np.stack(chunks, axis=0)  # [N, 24000]
        batch_tensor = torch.from_numpy(batch_np).to(self.device)

        with torch.no_grad():
            batch_mel = self.frontend(batch_tensor)
            logits = self.model(batch_mel)
            probs = torch.softmax(logits, dim=1)  # [N, 2]
            prob_female = float(probs[:, 1].mean().item())

        pred_label = 1 if prob_female >= 0.5 else 0
        return pred_label, prob_female, len(chunks)



# ------------------------------------------------------------------------------
# 4. CLI 메인 엔트리포인트 (대회 규격 준수)
# ------------------------------------------------------------------------------
def parse_args():
    parser = argparse.ArgumentParser(
        description="[Mission 1] 119 신고 전화 음성 기반 신고자 성별 분류 추론기"
    )
    # 주최 측 지정 필수 인자
    parser.add_argument("--audio_dir", "-a", type=str, required=True, help="평가 대상 .wav 파일들이 위치한 디렉토리 경로")
    parser.add_argument("--label_dir", "-l", type=str, required=True, help="라벨링 .json 파일들이 위치한 디렉토리 경로")
    parser.add_argument("--ckpt_path", "--checkpoint", "-c", type=str, required=True, help="학습 완료된 모델 가중치 파일 경로 (.pt)")
    parser.add_argument("--output", "-o", type=str, required=True, help="결과를 저장할 CSV 경로 (.csv)")

    # 선택 추가 옵션
    parser.add_argument("--device", "-d", type=str, default=None, help="연산 장치 (cuda 또는 cpu, 기본: 자동 감지)")

    return parser.parse_args()


def main():
    args = parse_args()

    audio_dir = Path(args.audio_dir)
    label_dir = Path(args.label_dir)
    ckpt_path = Path(args.ckpt_path)
    output_path = Path(args.output)

    if not audio_dir.is_dir():
        raise FileNotFoundError(f"❌ audio_dir 폴더를 찾을 수 없습니다: {audio_dir}")
    if not label_dir.is_dir():
        raise FileNotFoundError(f"❌ label_dir 폴더를 찾을 수 없습니다: {label_dir}")
    if not ckpt_path.is_file():
        raise FileNotFoundError(f"❌ ckpt_path 파일을 찾을 수 없습니다: {ckpt_path}")

    # 1. 폴더 내 복수 음원(.wav) 및 라벨(.json) 파일 목록 전수 스캔
    wav_files = {
        f.stem: f for f in audio_dir.glob("**/*")
        if f.is_file() and f.suffix.lower() == ".wav"
    }
    json_files = {
        f.stem: f for f in label_dir.glob("**/*")
        if f.is_file() and f.suffix.lower() == ".json"
    }

    all_stems = sorted(list(wav_files.keys()))
    total_calls = len(all_stems)

    if total_calls == 0:
        return

    matched_count = sum(1 for s in all_stems if s in json_files)

    # 2. 추론 엔진 초기화
    engine = GenderInferenceEngine(ckpt_path=ckpt_path, device=args.device)

    # 3. 폴더 내 모든 파일 일괄 추론 수행
    t0 = time.time()
    results = []

    # 라벨 표기 맵핑
    cur_map = {0: "M", 1: "F"}

    try:
        from tqdm.auto import tqdm
        iterator = tqdm(all_stems, desc="Batch Inference", dynamic_ncols=True)
    except ImportError:
        iterator = all_stems

    male_count = 0
    female_count = 0
    chunk_counts = []

    for idx, stem in enumerate(iterator):
        wav_file = wav_files[stem]
        json_file = json_files.get(stem, None)

        try:
            pred_label, prob_f, n_chunks = engine.infer_call(wav_file, json_file)
            gender_val = cur_map[pred_label]
            chunk_counts.append(n_chunks)
            if pred_label == 1:
                female_count += 1
            else:
                male_count += 1
        except Exception as e:
            # 오류 발생 시 기본값 'M' (0) 처리
            gender_val = cur_map[0]
            chunk_counts.append(1)
            male_count += 1

        results.append({
            "audio file name": wav_file.name,
            "gender": gender_val
        })

    elapsed_total = time.time() - t0

    # 4. 규격에 맞추어 CSV 저장: [audio file name], [gender]
    df_out = pd.DataFrame(results)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    df_out.to_csv(output_path, index=False, encoding="utf-8-sig")

if __name__ == "__main__":
    main()
