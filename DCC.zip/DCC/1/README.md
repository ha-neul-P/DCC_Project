# colab에서 실행하는 예제

# [Mission 1] 119 신고 전화 음성 기반 신고자 성별 분류 추론기

본 코드는 119 신고 전화 음성(.wav)과 라벨링 데이터(.json)를 입력받아 신고자의 성별(M/F)을 추론하는 파이프라인입니다.

## 1. 환경 설정 (Prerequisites)

원활한 실행을 위해 아래의 명령어를 사전 실행하시기 바랍니다. (코랩 T4 python3 기준 아래 명령어 없이도 실행가능합니다.)

```bash
pip install -r requirements.txt
```

```notebook-python
# -------------------------------------------------------------
# 사용자 환경에 맞는 경로 설정
# -------------------------------------------------------------
# 아래는 예제 환경이다. 수정 필요
AUDIO_DIR = "/content/1.원천데이터/VS_서울_구급"       # .wav 폴더 경로
LABEL_DIR = "/content/2.라벨링데이터/VL_서울_구급"      # .json 폴더 경로
CKPT_PATH = "/content/drive/MyDrive/K-ICT/대학부 데이터/Mission_1/last_final/final_submission_model.pth" # 가중치 파일
OUTPUT_CSV = "/content/outputs/Mission 1.csv"                                 # 결과 CSV 저장 경로

# -------------------------------------------------------------
# 실행
# -------------------------------------------------------------
!python inference.py \
  --audio_dir "{AUDIO_DIR}" \
  --label_dir "{LABEL_DIR}" \
  --ckpt_path "{CKPT_PATH}" \
  --output "{OUTPUT_CSV}"
```
