import torch
import torch.nn as nn
import torchaudio.transforms as T

class InferenceConfig:
    TARGET_SR: int = 8000               # 8,000Hz (전화 대역 최적화)
    TARGET_DURATION: float = 3.0        # 3초 고정 윈도우
    TARGET_SAMPLES: int = int(TARGET_SR * TARGET_DURATION)  # 24,000 samples
    STRIDE_SEC: float = 1.5             # 1.5초 스트라이드 (50% 중첩 슬라이싱)
    STRIDE_SAMPLES: int = int(TARGET_SR * STRIDE_SEC)       # 12,000 samples
    MIN_SEG_DURATION: float = 0.3       # 0.3초 미만 발화 노이즈 제외
    SILENCE_GAP_SEC: float = 0.1        # 발화 연결 시 삽입할 무음 버퍼

    # Mel-Spectrogram 파라미터
    N_FFT: int = 512
    WIN_LENGTH: int = 400
    HOP_LENGTH: int = 160
    N_MELS: int = 80
    F_MIN: float = 50.0
    F_MAX: float = 3800.0

class GPUMelFrontEnd(nn.Module):
    def __init__(self, sample_rate: int = 8000):
        super().__init__()
        self.mel_transform = T.MelSpectrogram(
            sample_rate=sample_rate,
            n_fft=InferenceConfig.N_FFT,
            win_length=InferenceConfig.WIN_LENGTH,
            hop_length=InferenceConfig.HOP_LENGTH,
            n_mels=InferenceConfig.N_MELS,
            f_min=InferenceConfig.F_MIN,
            f_max=InferenceConfig.F_MAX
        )
        self.amp_to_db = T.AmplitudeToDB()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        mel = self.amp_to_db(self.mel_transform(x)).unsqueeze(1)
        mean = mel.mean(dim=[-2, -1], keepdim=True)
        std = mel.std(dim=[-2, -1], keepdim=True) + 1e-6
        return (mel - mean) / std

class ConvBlock(nn.Module):
    def __init__(self, in_c: int, out_c: int):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_c, out_c, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_c),
            nn.SiLU(),
            nn.Conv2d(out_c, out_c, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_c),
            nn.SiLU(),
            nn.MaxPool2d(2, 2)
        )
        self.shortcut = nn.Sequential(
            nn.Conv2d(in_c, out_c, kernel_size=1, bias=False),
            nn.BatchNorm2d(out_c),
            nn.MaxPool2d(2, 2)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.conv(x) + self.shortcut(x)

class AudioClassifierCNN(nn.Module):
    def __init__(self, num_classes: int = 2):
        super().__init__()
        self.layer1 = ConvBlock(1, 32)
        self.layer2 = ConvBlock(32, 64)
        self.layer3 = ConvBlock(64, 128)
        self.layer4 = ConvBlock(128, 256)
        self.gap = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Sequential(
            nn.Dropout(0.4),
            nn.Linear(256, 128),
            nn.SiLU(),
            nn.Dropout(0.2),
            nn.Linear(128, num_classes)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.gap(x).flatten(1)
        return self.fc(x)